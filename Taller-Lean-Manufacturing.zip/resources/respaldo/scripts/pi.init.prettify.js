jQuery(function($){

	//region Google Prettify
	if(typeof(prettyPrint) === 'function'){
		prettyPrint();
	}
	//endregion

});