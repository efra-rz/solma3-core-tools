jQuery(function($){

	//region Parallax
	if($.fn.parallax){
		$('.pi-section-parallax').parallax("50%", 0.5);
	}
	//endregion

});