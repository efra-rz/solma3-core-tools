jQuery(function($){

	//region form placeholder
	if($.fn.placeholder){
		$('input, textarea').placeholder();
	}
	//endregion

});