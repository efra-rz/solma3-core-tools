jQuery(function($){

	$(".pi-img-w").fitVids();

});