<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'sZUHRHMRUd8pM5wHGKhwunxmY');
    define('CONSUMER_SECRET', 'a8VjxUeVU2sFQy16OLArQWZc8NePqDjrODJ7xJb0hGf7MfadLu');

    // User Access Token
    define('ACCESS_TOKEN', '2595192156-5zl8VTtyTaBlV61FTjXt4lR2b4hL4PtUR7OgHO5');
    define('ACCESS_SECRET', 'MfwMpXdAWnozMibOEAVAhVNG8fRDJ9GWrd05cPzZONL0t');